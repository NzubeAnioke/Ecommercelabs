<?php

require ("dbconnect.php");
if(isset($_POST['submit'])) {
 $name = $_POST['pname'];
 $phone= $_POST['phonenumber'];


 $sql = "INSERT INTO `phonebook`(`pname`, `pphoned`) VALUES ('$name','$phone')";
 $result=$connection->query($sql);

    if ($result === True) {
                
        echo "INSERTION DONE";
    }

    else{
    echo "INSERTION FAILED";

    }


}
?>
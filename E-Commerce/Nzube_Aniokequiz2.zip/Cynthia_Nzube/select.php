<a href="add.php">
<button type="button" class="btn btn-primary btn-lg btn-block">Add Contact</button>
</a>


<?php
    require ("dbconnect.php");
    $selectsql = "SELECT * FROM `phonebook`";
    $select = $connection->query($selectsql);
    if($select->num_rows >0){
        echo '<table class="table">
        <thead>
          <tr>
            
            <th scope="col">Name</th>
            <th scope="col">Phone Number</th>
            <th scope="col">Delete</th>
            <th scope="col">Update</th>
           
          </tr>
    
        </thead>
        <tbody>
        ';

        while($row = $select->fetch_assoc()){
            $id=$row['pid'];
            $name=$row['pname'];
            $number=$row['pphoned'];
            
            echo "
            <tr>
             
              <td>$name</td>
              <td>$number</td>
              
              <td>
              <form method='post' action='delete.php' style = 'display:inline;'>
              <input type='hidden'  name= 'pid' value ='$id' >
              <input type='hidden'  name= 'pname' value = '$name' >
              <input type='hidden' name='pphoned' value = '$number' >
          <input type='submit' value='Delete' name='Delete'>
          </form>
              </td>

              <td>
              <form method='post' action='update.php' style = 'display:inline;'>
    <input type='hidden'  name= 'pid' value ='$id'>
    <input type='hidden'  name= 'pname' value = '$name'>
    <input type='hidden' name='pphoned' value = '$number'>
<input type='submit' value='Update' name='Update'>
</form>
              </td>
            </tr>
           ";

        }

        echo " 
        </tbody>
      </table>";

    }


?>
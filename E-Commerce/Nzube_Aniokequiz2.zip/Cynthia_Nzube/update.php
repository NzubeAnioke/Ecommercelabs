<?php
require ("dbconnect.php");

//Update to a  database
$pid=null;
$name = null;
$number = null;


if(isset($_POST['Update'])) {
    $pid=$_POST['pid'];
$name = $_POST['pname'];
$number = $_POST['pphoned'];

  }
  ?>


<form action="update.php" method="post">
  <label for="pname">Phone Name </label><br>
  <input type="hidden" id="pname" value="<?php echo $pid;?>" name="pid">
  <input type="text" id="pname" value="<?php echo $name;?>" name="pname"><br>
  <label for="pphoned">Phone Number: </label><br>
  <input type="text" id="pphoned" value="<?php echo $number;?>"name="pphoned" >
  <input type="submit" name="Update2">
</form>



<?php 
    if(isset($_POST['Update2'])) {
        $pid=$_POST['pid'];
    $name = $_POST['pname'];
    $number = $_POST['pphoned'];
    $db = "UPDATE `phonebook` SET `pname`='$name',`pphoned`='$number' WHERE `pid`=$pid";
    
    if($connection->query($db) === TRUE){
          echo "UPDATED DONE";
        }
    
       else{
            echo "UPDATES FAILED";
        }
    
    
      }
?>
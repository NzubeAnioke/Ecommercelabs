<?php
$connection = mysqli_connect('localhost','root','','class_contact_mgt');
if ($connection->connect_error){
    die ("Not Connected" . $connection->connect_error);
}
else
{
//    echo "Connection succesful";
}


?>
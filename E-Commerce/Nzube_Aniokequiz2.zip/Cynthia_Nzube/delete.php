<?php
    require ("dbconnect.php");

    if(isset($_POST['Delete'])) {
        $pid = $_POST['pid'];
        $name = $_POST['pname'];
        $phone= $_POST['pphoned'];
        
    

    
    $sql = "DELETE FROM `phonebook` WHERE pid= '$pid' ";
    $result=$connection->query($sql);

    if ($result === True) {
                
        echo "DELETION DONE";
    }

    else{
    echo "DELETION FAILED";

    }
}

    ?>
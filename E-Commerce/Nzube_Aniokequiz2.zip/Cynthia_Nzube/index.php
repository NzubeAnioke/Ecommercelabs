<?php
header("Location:select.php")

?>
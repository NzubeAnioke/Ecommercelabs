<?php
//connect to database class
require("../settings/db_class.php");

/**
*General class to handle all functions 
*/
/**
 *@author David Sampah
 *
 */

class general_class extends db_connection
{
	//--INSERT--//
	

	//--SELECT--//



	//--UPDATE--//



	//--DELETE--//
	

}

?>
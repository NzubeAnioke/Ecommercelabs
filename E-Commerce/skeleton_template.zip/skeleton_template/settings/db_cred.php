<?php
//Database credentials


?>
<?php
//database

//database credentials
require('db_cred.php');

/**
 *@author David Sampah
 *@version 1.1
 */
class db_connection
{
	//properties
	

	//connect
	/**
	*Database connection
	*@return bolean
	**/
	

	//execute a query
	/**
	*Query the Database
	*@param takes a connection and sql query
	*@return bolean
	**/
	


	//execute a query with mysqli real escape string
	//to saveguard from sql injection
	/**
	*Query the Database
	*@param takes a connection and sql query
	*@return bolean
	**/
	


	//fetch a data
	/**
	*get select data
	*@return a record
	**/
	


	//fetch all data
	/**
	*get select data
	*@return all record
	**/
	


	//count data
	/**
	*get select data
	*@return a count
	**/
	
	
}
?>